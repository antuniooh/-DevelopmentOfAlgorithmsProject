#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef MENU_H_
#define MENU_H_

int menu();

#endif