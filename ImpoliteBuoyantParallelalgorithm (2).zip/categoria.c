#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "categoria.h"

int verifica(char* v, char* quer, int tamPalavra, int tam){

    int i=0, j=0;

    for (i = 0; i < tamPalavra; ++i) {
        if (v[i] != ' ') {
            if (v[i] == quer[j]) {
                j++;
            }
        }
    }

    if(j == tam)
        return 1;
    j=0;

    return 0;

}

void ImprimeCategoria(FILE *file, char* categoria){
    char c;
    char line[100000];
    int index = 0;
    
    memset(line, 0, sizeof(line)/sizeof(line[0]));
    c = getc(file);
    while ( 1 ) {
        
        if ( c != '\n'){
            line[index++] = c;
        }
        else {

            if(verifica(line, categoria, index, strlen(categoria))) {
                printf("%s\n", line);
            }
            line[index] = '\0';
            index = 0;

            memset(line, 0, sizeof(line));


        }
        if( c == EOF){
            printf("%s\n", line);
            break;
        }

        c = getc ( file );
        fclose(file);
    }
}

void Imprime(FILE *file){
  puts("Voce deseja ver o relatorio anual ou por categoria?");
  int op;
        puts("1 - Anual");
        puts("2 - Categoria");
        printf("Opcao > ");
        scanf(" %d", &op);
         while (op > 2 && op <= 0) {
            puts("Digite um comando valido");
            scanf("%d", &op);
        }
        puts("=================================");
        
        if(op == 1){

        }else{
         puts("Digite o nome da categoria a ser pesquisada");
        char categoriaR[100];
        scanf("%s", categoriaR);
        //printf("%s\n", categoriaR);
        ImprimeCategoria(file, categoriaR);

        }
}

