#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#ifndef REMOVER_H_
#define REMOVER_H_

void Remover(FILE *MyPersonalWallet, FILE *user);
void ApagaLinha(FILE *MyPersonalWallet, FILE *user, const int num);
void RemoverTudo();

#endif

