#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef INSERIR_H_
#define INSERIR_H_

void tiraEnter(char *s);
void Inserir (FILE *p, FILE* p_user, struct Usuario* u);

#endif