#ifndef CATEGORIA_H_
#define CATEGORIA_H_

void ImprimeCategoria(FILE *file, char* categoria);

#endif