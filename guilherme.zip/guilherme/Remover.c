#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>


void ApagaLinha(FILE *MyPersonalWallet, FILE *user, const int num)
{
    FILE *file;
    FILE *file2;

    char v[1000], v2[1000], v3[1000], c;
    int cont=1, index=0, index2=0, bol=0;
    float transacao=0, saldo=0;

    file = fopen("MyPersonalWallet_Temp.txt", "w");
    file2 = fopen("user_Temp.txt", "w");

    memset(v, 0, sizeof(v)/sizeof(v[0]));
    memset(v3, 0, sizeof(v3)/ sizeof(v3[0]));



    while (1)
    {
        c=fgetc(MyPersonalWallet);
        if(c == '\n')cont++;

        if(cont == 2){
            if(c == '+' || c == '-'){
                bol=1;
            }
            if(bol==1){
                v2[index2++] = c;
            }
            continue;
        }
        else {
            v[index] = c;
            index++;
        }
        if(c == EOF){
            break;
        }

    }

    v3[0] = v2[0];
    int j=3;

    while(v2[j] != ' '){
        v3[j-2] = v2[j];
        j++;
    }

    transacao = atof(v3);

    memset(v2, 0,sizeof(v2)/ sizeof(v2[0]));

    cont=1;

    while(fgets(v2, sizeof(v2), file3)){

        if (cont == 3){
            saldo = atof(v2);
            fprintf(file2, "%f\n", saldo+transacao);
        }
        else{
            fprintf(file2, "%s", v2);
        }
        cont++;


    }

    for (int i = 0; i < index-1; ++i) {
        fprintf(file, "%c", v[i]);
    }

    fclose(file);
    fclose(file2);
    remove("MyPersonalWallet.txt");
    remove("user.txt");
    rename("MyPersonalWallet_Temp.txt", "MyPersonalWallet.txt");
    rename("user_Temp.txt", "user.txt");


}

void Remover(){

    int status = remove("MyPersonalWallet.txt");
    int status2 = remove("user.txt");

    if (status == 0)
        printf("Historico de transacoes removidas\n");
    if(status2 == 0)
        printf("Dados de usuario deletados\n");
    if(status2 != 0)
    printf("Nao foi possiver remover o Historico de transacoes\n");
    else
    {
        printf("Nao foi possiver remover Dados de usuario deletados\n");
    }
}

