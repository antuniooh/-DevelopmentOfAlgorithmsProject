#ifndef CATEGORIA_H_
#define CATEGORIA_H_

void Imprime(FILE *file);
void ImprimeCategoria(FILE *file, char* categoria);

#endif